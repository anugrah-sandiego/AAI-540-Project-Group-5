# Group 5: automate the original five module commands

Prepared against repository commit fb360f633623f57ff8b12c9e7febd7e6d8be7190.
Repository: https://github.com/anugrah-sandiego/AAI-540-Project-Group-5
Date: 17 October 2026.

## What changes

The workflow now executes these original public module commands:

1. `python -m src.aws.sagemaker.data_upload`
2. `python -m src.aws.sagemaker.feature_store`
3. `python -m src.aws.sagemaker.training`
4. `python -m src.aws.sagemaker.model_registry`
5. `python -m src.aws.sagemaker.deployment`

An explicit evaluation job (`python -m cicd.release evaluate`) runs between training
and registration. Production cleanup also uses the shared release engine.
Failures stop downstream work. No `|| true`, `|| echo skipped`, or `continue-on-error`
is added. The production job waits for review only when the GitHub production
environment has required reviewers configured.

Important implementation detail: the YAML sets `GROUP5_CI=1`. Four module entrypoints
select a new CI adapter before importing the legacy SageMaker SDK. In this mode,
training, registry and deployment reuse the existing `cicd.release` engine. This is
intentional: the legacy generated trainer saved a classifier without its fitted
encoder and the legacy deployment CLI used a historical hard-coded artifact.
The CI adapter uses the shared fitted-preprocessing model/JSON serving format instead.
Legacy importable classes and non-CI CLI behavior remain unchanged.
Do NOT remove GROUP5_CI or mix a legacy classifier artifact with the CI serving bundle.
This patch automates your original command names, not an exact reproduction of the
historical local/manual model implementation. Each CI candidate is independently evaluated.

## Install into SageMaker

1. Download Group5_Original_Modules_CICD_Fix.zip to your computer.
2. Upload it with JupyterLab's file browser into your repository root.
3. Ensure `git status` is clean; commit or preserve any current work first.
4. Extract the ZIP (it overwrites the listed workflow/module files):

```bash
cd ~/AAI-540-Project-Group-5
unzip -o Group5_Original_Modules_CICD_Fix.zip
```

The bundle contains complete updated files and an optional patch.
Use the complete files OR apply group5-original-modules.patch against the stated
base commit. Do not do both. If your repository changed since the base, review the
diff before overwriting. The bundle does not contain credentials or modify GitHub secrets.

5. Review the files:

```bash
git diff -- .github/workflows/ci-cd.yml src/aws/sagemaker/
git status --short
```

6. Optionally run the local checks in an isolated environment:

```bash
python -m venv .venv-ci
source .venv-ci/bin/activate
python -m pip install -r cicd/requirements-ci.txt
python -m pip check
ruff check src cicd --select E9,F63,F7,F82
python -m pytest tests -q
```

7. Commit and push (this push starts billable AWS work after CI passes):

```bash
git add .github/workflows/ci-cd.yml src/aws/sagemaker/data_upload.py src/aws/sagemaker/feature_store.py src/aws/sagemaker/training.py src/aws/sagemaker/model_registry.py src/aws/sagemaker/deployment.py src/aws/sagemaker/ci_entrypoints.py tests/cicd/test_original_cli.py docs/ORIGINAL_MODULE_CICD_FIX.md docs/ORIGINAL_MODULE_CICD_VALIDATION.md
git commit -m "Automate original SageMaker modules with CI artifact handoff"
git pull --rebase origin main
git push origin main
```

Do not force-push if the rebase reports conflicts; resolve them before continuing.
Do not add the ZIP or optional patch to the commit. No git push or cloud action was
performed by the assistant.

## Prerequisites already in your repository

The previously supplied `cicd/` package, its container scripts, requirements-ci.txt,
and tests/cicd/test_release.py must remain committed. This is an incremental fix,
not a standalone replacement for that package. GitHub secrets must contain valid
AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY and AWS_SESSION_TOKEN from one active
Learner Lab session. Account/role/region are not substitutes for these credentials.

GitHub environments `lab` and `production` must allow main. Required reviewers must
be explicitly configured if an approval pause is wanted. Refresh temporary credentials
before an extended review delay expires them. A green secret-presence check only means
values exist, not that they are valid. The subsequent authentication step verifies that.

Bucket sagemaker-us-east-1-562792440372 must exist in us-east-1. This fix does not create
or empty buckets. Repository file data/raw/bank-full.csv must exist. The uploader now
fails clearly instead of silently skipping a missing main CSV. Optional bank.csv and
bank-names.txt are uploaded when present. Existing extra S3 files are not removed.

The completed reference job bank-marketing-training-20261011-095612 must remain
describable so the shared trainer can resolve its framework image. This job's MODEL is
not reused. If the reference job is gone, choose another completed scikit-learn 1.2-1
job or configure a verified TRAINING_IMAGE_URI in the shared engine and adapt the
preflight describe step accordingly. Do not use an XGBoost image with sklearn scripts.

## Data and model handoff

- Upload runs BEFORE the S3 head-object check; the missing-raw-input bootstrap gap is fixed.
- The Feature Store step reads uploaded raw data from S3.
- The training module in CI calls prepare first: validates raw data and writes actual
  train/validation/test Parquet splits to an immutable run prefix in S3.
- Managed training consumes those new split URIs and saves the fitted preprocessing bundle.
- Validation selects a threshold; test ROC-AUC and top-10% lift are checked in evaluate.
- Training writes exact training_job, model_uri and image to artifacts/release.json.
- TRAINING_JOB_NAME and MODEL_ARTIFACT_URI are also exported to GITHUB_ENV inside the
  training job. Across JOBS, the release.json artifact is authoritative.
- Registration reads that manifest and refuses candidates without passed quality gates.
- Deployment reads the registered package ARN, approves it after the protected job starts,
  creates staging, checks exact fixture parity, and promotes with recovery handling.
- Staging cleanup runs with always(), including after deployment failure.
- The trained model is a new CI candidate; historical local model results do not validate it.

## Feature Store behavior

The CI path uses boto3 APIs, so it does not add the legacy SageMaker SDK to CI requirements.
It creates the offline group only if missing, waits for readiness, and validates existing
feature definitions plus identifier/event-time names. A schema mismatch is an explicit
failure, not a reason to silently replace a group. Configure FEATURE_GROUP_NAME to a
new name only after reviewing whether a new group is appropriate.

The record ID is source-SHA prefix plus row position. It identifies a dataset row, NOT
an actual bank customer. Raw fields include duration and y in this auxiliary store;
the training input drops duration/y from predictors. The training job still reads S3,
not Feature Store. No online Feature Store is created by the CI path.

A successful ingestion creates a checkpoint under:
`s3://sagemaker-us-east-1-562792440372/aai540/bank-marketing/cicd/feature-store-checkpoints/<group>/<group-generation>/<source-sha>.json`

Subsequent pushes with the same CSV and group generation skip ingestion. A newly created
or recreated group, a changed source, or FORCE_FEATURE_INGESTION=1 causes ingestion.
There can be a one-time ingestion even if the historical SDK run populated the group,
since that run did not write this new checkpoint. The new source-row IDs also differ
from historical positional IDs. A partial failed ingestion has no checkpoint; retrying
can create additional offline record versions. This is not exactly-once ingestion.
Successful PutRecord responses indicate accepted ingestion; offline S3 delivery is
asynchronous and is not asserted as immediately queryable by this step.

Ingestion uses four workers by default; change FEATURE_INGEST_WORKERS (1-16) only within
account quotas. Throttles use boto3 standard retries. Access errors or exhausted retries
fail the pipeline. A checkpoint is written only after every record call completes.

## AWS paths

- Raw data: s3://sagemaker-us-east-1-562792440372/aai540/bank-marketing/raw/bank-full.csv
- Feature Store group: bank-marketing-features
- Configured offline prefix: s3://sagemaker-us-east-1-562792440372/aai540/bank-marketing/feature-store/
- CI run root: s3://sagemaker-us-east-1-562792440372/aai540/bank-marketing/cicd/gh-<run-id>-<attempt>/
- Splits: <run-root>/processed/train.parquet, validation.parquet, test.parquet
- Model: <run-root>/models/bank-ci-gh-<run-id>-<attempt>/output/model.tar.gz
- Registry group: bank-marketing-models (new package ARN recorded in release.json)
- Production endpoint: bank-marketing-production
- Staging: bank-stage-gh-<run-id>-<attempt> (cleanup attempted after deploy)
- Deployment state: Actions artifact state-deploy / release.json
- Feature ingestion state: Actions artifact state-train / feature_store.json

## Permissions, failure checks and costs

The caller needs S3 upload/read/write, SageMaker Feature Store describe/create and runtime
PutRecord, training/package/model/endpoint operations, InvokeEndpoint, CloudWatch dashboard
and alarm operations, and iam:PassRole for LabRole. The role itself needs S3/ECR/logging
and offline Feature Store permissions including applicable Glue/catalog permissions.
Do not add broad policies to a restricted course role; ask the course administrator
when a permission is denied. No script can guarantee permissions or bypass a lab restriction.

The earlier resource check only exposed exit code 254 to the assistant; the exact AWS
service error was not available. Upload-first fixes a missing raw object but does not
prove that was the only blocker. A missing reference training job or denied operation
must still be diagnosed using the actual expanded error. An unnecessary registry-list
preflight was removed; registry operations are validated at their real stage instead.

The workflow retains S3 capture, operational CloudWatch metrics/dashboard/alarm. It does
not implement bias/data/model-quality scheduled monitors or automatic retraining.
Production uses two ml.m5.xlarge instances; staging uses one. Feature Store ingestion,
offline storage, training, CloudWatch and capture storage may also incur charges.
After cancellation or expired credentials inspect AWS for unfinished cleanup. Production
is intentionally retained and continues billing. This patch does not touch the historical
bank-marketing-endpoint-20261011-101615 endpoint.
